Run gta5.exe to start the game

Internet access may be rquired for the first time.